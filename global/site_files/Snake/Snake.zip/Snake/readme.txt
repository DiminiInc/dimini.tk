﻿English/Русский
----------------------------------------------------------------------------

English

Instruction
1.Unzip all files from archive
2.Execute Snake.exe
3.Play

DON'T DELETE FILES:
Achievements.bin
Game.bin
Highscores.bin
Settings.bin
Statistics.bin
libeay32.dll
ssleay32.dll
because they are used by programme.

----------------------------------------------------------------------------

Русский

Инструкция
1.Распакуйте все файлы архива
2.Запустите Snake.exe
3.Играйте

НЕ УДАЛЯЙТЕ ФАЙЛЫ:
Achievements.bin
Game.bin
Highscores.bin
Settings.bin
Statistics.bin
libeay32.dll
ssleay32.dll
так как они используются программой.

----------------------------------------------------------------------------


© Dimini Inc., 2017